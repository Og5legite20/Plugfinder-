import React from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { HowItWorks } from './components/HowItWorks';
import { VendorCategories } from './components/VendorCategories';
import { Testimonials } from './components/Testimonials';
import { CtaSection } from './components/CtaSection';
import { Footer } from './components/Footer';
export function App() {
  return <div className="font-sans min-h-screen bg-white text-gray-800">
      <Header />
      <main>
        <HeroSection />
        <HowItWorks />
        <VendorCategories />
        <Testimonials />
        <CtaSection />
      </main>
      <Footer />
    </div>;
}