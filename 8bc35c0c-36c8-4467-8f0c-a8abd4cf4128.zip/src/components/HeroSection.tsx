import React from 'react';
import { Search } from 'lucide-react';
export function HeroSection() {
  return <section className="bg-gradient-to-r from-blue-600 to-blue-500 text-white py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-8">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            Find Trusted Vendors Instantly
          </h2>
          <p className="text-lg md:text-xl mb-8 opacity-90">
            Connect with verified vendors across Nigeria for all your needs -
            from fashion to tech, delivery to services.
          </p>
          <div className="relative max-w-2xl mx-auto">
            <div className="flex items-center bg-white rounded-full shadow-lg overflow-hidden p-1">
              <div className="pl-4 text-gray-400">
                <Search size={20} />
              </div>
              <input type="text" placeholder="What service are you looking for?" className="w-full p-3 pl-2 text-gray-700 focus:outline-none" />
              <button className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-6 rounded-full transition-colors">
                Search
              </button>
            </div>
          </div>
          <div className="mt-6 text-sm opacity-80">
            Popular: Fashion, Electronics, Delivery, Crypto Exchange, Home
            Services
          </div>
        </div>
        <div className="mt-12 max-w-4xl mx-auto bg-white/10 backdrop-blur-sm rounded-xl p-4 flex flex-wrap justify-center gap-4 md:gap-8">
          <div className="text-center">
            <div className="font-bold text-2xl md:text-3xl">1,200+</div>
            <div className="text-sm opacity-80">Verified Vendors</div>
          </div>
          <div className="text-center">
            <div className="font-bold text-2xl md:text-3xl">24/7</div>
            <div className="text-sm opacity-80">Customer Support</div>
          </div>
          <div className="text-center">
            <div className="font-bold text-2xl md:text-3xl">50+</div>
            <div className="text-sm opacity-80">Service Categories</div>
          </div>
          <div className="text-center">
            <div className="font-bold text-2xl md:text-3xl">98%</div>
            <div className="text-sm opacity-80">Satisfaction Rate</div>
          </div>
        </div>
      </div>
    </section>;
}