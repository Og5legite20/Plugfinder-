import React from 'react';
import { MenuIcon } from 'lucide-react';
export function Header() {
  return <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center">
          <h1 className="text-2xl font-bold text-blue-600">
            Plug<span className="text-black">Finder</span>
          </h1>
        </div>
        <div className="hidden md:flex items-center space-x-6">
          <a href="#" className="text-gray-600 hover:text-blue-600 font-medium">
            Categories
          </a>
          <a href="#" className="text-gray-600 hover:text-blue-600 font-medium">
            How It Works
          </a>
          <a href="#" className="text-gray-600 hover:text-blue-600 font-medium">
            For Vendors
          </a>
          <a href="#" className="text-gray-600 hover:text-blue-600 font-medium">
            About Us
          </a>
        </div>
        <div className="flex items-center space-x-4">
          <a href="#" className="hidden md:block bg-blue-600 text-white px-4 py-2 rounded-full font-medium hover:bg-blue-700 transition-colors">
            Sign Up
          </a>
          <a href="#" className="hidden md:block text-blue-600 font-medium hover:text-blue-700">
            Log In
          </a>
          <button className="md:hidden text-gray-600 hover:text-blue-600">
            <MenuIcon size={24} />
          </button>
        </div>
      </div>
    </header>;
}