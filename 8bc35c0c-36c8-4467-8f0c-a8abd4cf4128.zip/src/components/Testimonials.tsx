import React from 'react';
import { Star } from 'lucide-react';
export function Testimonials() {
  const testimonials = [{
    name: 'Chioma A.',
    role: 'Fashion Designer',
    image: 'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80',
    quote: 'PlugFinder helped me find reliable fabric suppliers for my business. The verification process gave me confidence in my choice.',
    rating: 5
  }, {
    name: 'Emeka O.',
    role: 'Tech Entrepreneur',
    image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80',
    quote: 'I needed to find a trustworthy crypto exchange quickly. PlugFinder connected me with a vendor who exceeded my expectations.',
    rating: 5
  }, {
    name: 'Amina K.',
    role: 'Student',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=100&q=80',
    quote: "As a student in Lagos, finding a reliable gadget repair service was difficult until I discovered PlugFinder. Now it's my go-to platform.",
    rating: 4
  }];
  return <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">What Our Users Say</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Join thousands of satisfied users who have found trusted vendors
            through PlugFinder.
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {testimonials.map((testimonial, index) => <div key={index} className="bg-white p-6 rounded-xl shadow-sm">
              <div className="flex items-center space-x-1 mb-4">
                {[...Array(5)].map((_, i) => <Star key={i} size={18} className={i < testimonial.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'} />)}
              </div>
              <p className="text-gray-600 mb-6 italic">"{testimonial.quote}"</p>
              <div className="flex items-center">
                <img src={testimonial.image} alt={testimonial.name} className="w-12 h-12 rounded-full object-cover mr-4" />
                <div>
                  <h4 className="font-bold">{testimonial.name}</h4>
                  <p className="text-gray-500 text-sm">{testimonial.role}</p>
                </div>
              </div>
            </div>)}
        </div>
        <div className="text-center mt-12 bg-white p-6 rounded-xl shadow-sm max-w-3xl mx-auto">
          <div className="flex flex-wrap justify-center gap-4 mb-6">
            <div className="text-center px-4">
              <div className="font-bold text-2xl md:text-3xl text-blue-600">
                4.8/5
              </div>
              <div className="text-sm text-gray-500">Average Rating</div>
            </div>
            <div className="text-center px-4">
              <div className="font-bold text-2xl md:text-3xl text-blue-600">
                15,000+
              </div>
              <div className="text-sm text-gray-500">Happy Customers</div>
            </div>
            <div className="text-center px-4">
              <div className="font-bold text-2xl md:text-3xl text-blue-600">
                93%
              </div>
              <div className="text-sm text-gray-500">Return Rate</div>
            </div>
          </div>
          <a href="#" className="inline-block text-blue-600 font-medium hover:text-blue-700">
            Read more testimonials
          </a>
        </div>
      </div>
    </section>;
}