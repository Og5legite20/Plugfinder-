import React from 'react';
import { Search, CheckCircle, Zap } from 'lucide-react';
export function HowItWorks() {
  return <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">How PlugFinder Works</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Finding reliable vendors in Nigeria has never been easier. Our
            simple 3-step process connects you with trusted service providers in
            minutes.
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          <div className="bg-white p-6 rounded-xl shadow-sm text-center">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="text-blue-600" size={28} />
            </div>
            <h3 className="text-xl font-bold mb-3">1. Search</h3>
            <p className="text-gray-600">
              Enter what you're looking for in our search bar or browse through
              categories to find the perfect vendor.
            </p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-sm text-center">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="text-blue-600" size={28} />
            </div>
            <h3 className="text-xl font-bold mb-3">2. Choose</h3>
            <p className="text-gray-600">
              Compare ratings, reviews, and prices from our verified vendors to
              find the best match for your needs.
            </p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-sm text-center">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Zap className="text-blue-600" size={28} />
            </div>
            <h3 className="text-xl font-bold mb-3">3. Connect</h3>
            <p className="text-gray-600">
              Contact your chosen vendor directly through our platform and get
              your needs fulfilled quickly and efficiently.
            </p>
          </div>
        </div>
        <div className="text-center mt-10">
          <a href="#" className="inline-flex items-center text-blue-600 font-medium hover:text-blue-700">
            Learn more about our vetting process
            <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </a>
        </div>
      </div>
    </section>;
}