import React from 'react';
import { ShoppingBag, Smartphone, DollarSign, Truck } from 'lucide-react';
export function VendorCategories() {
  const categories = [{
    name: 'Fashion & Clothing',
    icon: <ShoppingBag size={24} />,
    description: 'Clothing vendors, tailors, stylists and fashion accessories',
    color: 'bg-pink-100 text-pink-600'
  }, {
    name: 'Gadgets & Electronics',
    icon: <Smartphone size={24} />,
    description: 'Phones, laptops, accessories and electronics repair',
    color: 'bg-blue-100 text-blue-600'
  }, {
    name: 'Crypto & Finance',
    icon: <DollarSign size={24} />,
    description: 'Cryptocurrency exchange, financial services and fintech',
    color: 'bg-green-100 text-green-600'
  }, {
    name: 'Delivery & Logistics',
    icon: <Truck size={24} />,
    description: 'Package delivery, moving services and transportation',
    color: 'bg-orange-100 text-orange-600'
  }];
  return <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Explore Vendor Categories</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            From fashion to finance, find verified vendors across multiple
            categories to meet all your needs.
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          {categories.map((category, index) => <div key={index} className="bg-white border border-gray-100 rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow">
              <div className={`p-6 text-center ${category.color} bg-opacity-20`}>
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full mb-4 bg-white">
                  {category.icon}
                </div>
                <h3 className="text-xl font-bold mb-1">{category.name}</h3>
                <p className="text-gray-600 text-sm">{category.description}</p>
              </div>
              <div className="p-4 border-t border-gray-100">
                <a href="#" className="text-blue-600 text-sm font-medium hover:text-blue-700 flex justify-between items-center">
                  <span>Explore vendors</span>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </a>
              </div>
            </div>)}
        </div>
        <div className="text-center mt-10">
          <a href="#" className="inline-block bg-blue-100 text-blue-600 px-6 py-3 rounded-full font-medium hover:bg-blue-200 transition-colors">
            View All Categories
          </a>
        </div>
      </div>
    </section>;
}